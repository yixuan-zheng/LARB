Outcome-blinded continuation-benefit prediction, v1

You are one independent AI reader. Read ONLY this rubric, your INVENTORY.json and your cases/ files. Do not access any repository, parent conversation, another reader/condition, internet, benchmark answer key, later branches, or prior annotations. Do not spawn agents. Do not complete the mathematical problem or recall a known benchmark answer.

Both input conditions share this target and served-model specification. The served model is Qwen3-4B, BF16, temperature 0.6, top_p 0.95 and top_k 20. A request has reached 4096 generated reasoning tokens with thinking still open. One possible action forces the existing closing cue and allows a final answer under a 2048-token allowance. The other continues this SAME prefix up to 8192 total reasoning tokens, permits natural closure, and gives the same final-answer allowance. An accepted correct answer must finish normally and give the correct final boxed integer. These allowances are ceilings. Additional reasoning can help, do nothing, or hurt.

Predict the joint distribution of the TWO possible final outcomes. Supply integer probabilities summing to 100:
ww — both short and long incorrect or not normally completed
wc — short incorrect, long correct
cw — short correct, long incorrect
cc — both short and long correct

This is a forecast of the served model's outcomes, not whether you personally can solve the question, how hard it looks, or whether the prefix appears confident. The allocation target is expected marginal correctness benefit wc minus cw.

For a question-only packet, no trajectory is supplied. Forecast over unknown 4K prefixes conditional on this model still reasoning at 4K. Do not invent a specific prefix or branch. There is one entry per distinct question, and the same forecast will be reused for its observed prefix seeds.

For a question-plus-prefix packet, the full saved prefix is supplied. Condition your forecast on that ACTUAL prefix. Read it in full. You may assess apparent progress, completed obligations, errors and likely repair, without solving what remains. Neither outcome is supplied.

Return one JSON object per case with case_id, ww, wc, cw, cc, evidence, rationale. evidence must be an exact contiguous excerpt <=300 characters from supplied prefix for the prefix condition or from the question for the question-only condition. rationale should briefly explain the forecast and remaining uncertainty. No threshold, ranking, or allocation decision is requested from you.

Append each small batch to annotations.jsonl. Use output limits that permit full reading. At completion write reader-attestation.json listing all files accessed, cases completed, whether all input was read fully, all access/truncation limitations, and confirmation that both your identity and judgments are AI rather than human. State no outcome, repository, other-reader or internet access. Do not revise judgments after outcome access. Formatting/quote fixes before completion are permitted. Report only progress counts and final output paths to the parent.
