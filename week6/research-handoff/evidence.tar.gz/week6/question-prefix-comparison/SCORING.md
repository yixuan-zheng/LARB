# Frozen scoring specification

The primary population is the 57 eligible, still-reasoning prefixes. The three early-answer instances are carried identically into secondary 60-instance accounting. Primary quality and cost gates use the 57 eligible instances.

Each forecast supplies probabilities for WW, WC, CW and CC. The expected marginal correctness benefit is P(WC) minus P(CW). Joint forecasts are averaged across the two readers in each condition. No fitted calibration or outcome-selected threshold is used.

Question-only forecasts are collected once for each of 30 questions, conditioned on the served model reaching 4K with reasoning still open. The forecast is reused across its eligible seeds. Prefix readers receive 57 actual trajectories. Both conditions use new sessions, the same model and instructions, and the same joint-outcome target. The previous readiness labels are outside this matched comparison.

Fixed fractions are 0%, 25%, 50%, 75% and 100%, rounded down to a count out of 57. Half allocation, 28 extensions, is primary. Tied scores receive equal fractional selection probability at the cutoff. Report expected correctness and tokens under uniform random tie resolution. A fractional answer count is an expectation over the tie, not a new measured response.

All comparisons use the saved short and long branch records. Ranking uses only blinded predicted net benefit, with a constant additional-token planning reserve. It does not use realized suffix lengths or correctness to choose an extension. Same-count random allocation is a diagnostic baseline. Equal extension counts have equal planning reserve but can have different realized output-token costs.

A primary pass requires at least two more expected correct answers for prefix than question-only at 28 extensions, preservation of fixed-long correctness, at most 85% of fixed-long tokens, no greater realized token cost than question-only, and a strictly higher benefit score for the gaining seed in at least three of the four discordant questions. These are proposed engineering gates for this incremental-information test, rather than a power calculation or a formal noninferiority claim.

If any point gate fails, stop the incremental-prefix branch under this comparison. If they pass but a paired question-cluster bootstrap confidence interval for prefix-minus-question correctness includes zero, classify inconclusive. A full pass earns review of practical signal feasibility. Neither stop nor inconclusive means that no trajectory information could ever be useful.

Bootstrap 10,000 resamples of 30 questions with both eligible seeds kept, using seed 157222. Recompute a half-allocation count floor(0.5*N) and tie weights inside each resample. Report the difference in accuracy fractions. No seed is treated as an independent question.

Prediction metrics include gain ranking by net score, ranking by gain probability, tie-averaged average precision, joint Brier score and net-benefit MSE. Reader agreement is descriptive Pearson correlation and mean absolute probability difference. Cohen kappa from the previous categorical study is not an appropriate gate for this new probabilistic task.

The remaining budget grid, reader-specific results, random-allocation expectation and 60-instance totals are descriptive. Do not select a favorable alternative budget as a replacement primary endpoint. Every original question/split and outcome is exploratory, regardless of reader blinding. Common AI model biases, pretraining familiarity, and procedural rather than OS-enforced isolation limit interpretation. Reader inference overhead and real serving goodput are unmeasured.
