"""CPU audit of preserved raw pairs. Does not modify collected evidence."""
import csv
import hashlib
import json
import random
import statistics
from collections import Counter
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE/'job-6878140-shared-prefix'


def read(path):
    return json.loads(path.read_text())


def token_hash(ids):
    return hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()


def main():
    manifest=read(ROOT/'manifest.json')
    close,eos,cue=manifest['close_id'],manifest['eos_id'],manifest['cue_ids']
    rows=read(ROOT/'graded-pairs.json')
    questions={q['id']:q for q in read(ROOT/'questions.json')}
    assert len(rows)==60 and len({r['key'] for r in rows})==60
    lock=read(ROOT/'source-lock.json')
    for name,expected in lock.items():
        assert hashlib.sha256((ROOT/'sources'/name).read_bytes()).hexdigest()==expected,name
    rule=read(ROOT/'calibration-seal.json')['rule']
    rescues=[]
    csv_rows=[]
    times={k:[] for k in ['short','long','selected']}
    for row in rows:
        p=read(ROOT/'pairs'/f"{row['key']}.json")
        initial=read(ROOT/'calls'/f"{row['key']}-prefix.json")
        ids=p['prefix_token_ids']
        assert p['complete'] and initial['complete']
        assert ids==initial['token_ids'] and p['prefix_hash']==token_hash(ids)
        assert initial['input_token_ids']==p['prompt_token_ids']
        if row['eligible']:
            assert len(ids)==4096 and close not in ids
            score=statistics.mean(initial['sampled_logprobs'][-256:])
            assert abs(score-p['score'])<1e-12
        else:
            assert close in ids
            assert p['branches']['short']==p['branches']['long']
        selected='long' if row['eligible'] and row['score']<rule['threshold'] else 'short'
        for branch,budget in [('short',4096),('long',8192)]:
            b=p['branches'][branch];full=b['token_ids']
            assert full[-1]==eos and full.count(close)==1
            at=full.index(close)
            assert at<budget or full[budget:budget+len(cue)]==cue
            assert b['normal']==(len(full)-at-1<=2048)
            assert 151667 not in full[at+1:]
            if row['eligible']:
                raw=read(ROOT/'calls'/f"{row['key']}-{branch}.json")
                assert raw['complete']
                assert raw['input_token_ids']==p['prompt_token_ids']+ids
                assert full==ids+raw['token_ids']
            assert len(full)==row['outcomes'][branch]['tokens']
        if row['split']=='evaluation':
            for name,branch in [('short','short'),('long','long'),('selected',selected)]:
                times[name].append(p['prefix_seconds']+p['branches'][branch]['suffix_seconds'])
        short,long=(row['outcomes'][b] for b in ['short','long'])
        gain=not short['correct'] and long['correct']
        if row['split']=='evaluation' and gain:
            rescues.append(dict(key=row['key'],question=questions[row['id']]['stable_id'],
                selected=selected,short_reason=short['reason'],
                short_tokens=short['tokens'],long_tokens=long['tokens']))
        csv_rows.append(dict(key=row['key'],question=questions[row['id']]['stable_id'],
            split=row['split'],block=row['block'],eligible=row['eligible'],score=row['score'],
            selected=selected,short_correct=short['correct'],long_correct=long['correct'],
            short_tokens=short['tokens'],long_tokens=long['tokens'],
            short_reason=short['reason'],long_reason=long['reason']))
    evaluation=[r for r in rows if r['split']=='evaluation']
    # Independently derive cheapest allocation preserving every fixed-long success.
    oracle_cost=0
    for row in evaluation:
        acceptable=[o for o in row['outcomes'].values()
                    if o['correct'] or not row['outcomes']['long']['correct']]
        oracle_cost+=min(o['tokens'] for o in acceptable)
    assert oracle_cost==read(ROOT/'decision.json')['oracle']['tokens']
    rng=random.Random(56222)
    by_question={i:[r for r in evaluation if r['id']==i] for i in sorted({r['id'] for r in evaluation})}
    intervals=[]
    for _ in range(10000):
        sample=[r for i in rng.choices(list(by_question),k=len(by_question)) for r in by_question[i]]
        intervals.append(sum(int(r['outcomes']['long']['correct'])-int(r['outcomes']['short']['correct'])
                             for r in sample)/len(sample))
    intervals.sort()
    calls=[read(p) for p in (ROOT/'calls').glob('*.json')]
    assert all(c['complete'] for c in calls)
    assert sum(c['engineering'] for c in calls)==6
    measured=[c for c in calls if not c['engineering']]
    seal=read(ROOT/'calibration-seal.json')
    assert all(hashlib.sha256((ROOT/'pairs'/f'{key}.json').read_bytes()).hexdigest()==expected
               for key,expected in seal['calibration_pair_sha256'].items())
    result=dict(source_files_verified=len(lock),prefixes_verified=60,
        measured_calls=len(measured),engineering_calls=6,
        measured_generated_tokens=sum(len(c['token_ids']) for c in measured),
        eligible_total=sum(r['eligible'] for r in rows),
        evaluation_eligible=sum(r['eligible'] for r in evaluation),
        gains=rescues,distinct_gain_questions=len({r['question'] for r in rescues}),
        long_minus_short_accuracy_ci95=[intervals[249],intervals[9749]],
        oracle_cost_independent=oracle_cost,
        reconstructed_mean_seconds={k:statistics.mean(v) for k,v in times.items()},
        extraction_issues={b:dict(Counter(r['outcomes'][b]['issue'] or 'none' for r in evaluation)) for b in ['short','long']},
        overhead_time_sensitivity=[dict(overhead=x,
          selected_to_long_time_ratio=statistics.mean(times['selected'])*(1+x)/statistics.mean(times['long']))
          for x in [0,0.01,0.05,0.10]])
    (HERE/'AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    with (HERE/'pair-outcomes.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(csv_rows[0]))
        writer.writeheader();writer.writerows(csv_rows)
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
