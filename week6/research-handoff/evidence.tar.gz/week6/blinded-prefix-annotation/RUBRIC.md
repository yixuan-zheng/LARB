Independent prefix-state annotation rubric v1

Read only this rubric and the case files in your assigned packet. No repository, parent chat, other reader output, internet, gold answers, later branches, or outcome analysis may be accessed. Do not spawn agents. You are an independent AI reader, judging the information visible at a reasoning checkpoint. The dataset contains no labels in the packet.

For each case read the entire supplied question and entire reasoning prefix. Judge the state at the end of the prefix. Do not complete the problem, consult external sources, or use remembered benchmark answers. Assess the apparent state even if the candidate might ultimately be wrong.

Assign exactly one label:
A — answer-ready. A candidate resolving the question's requested output is already supported by an apparently complete route in the prefix. Further text is chiefly rechecking, reformulation, or presentation. A mere assertion without addressing the question's requirements is insufficient.
B — unfinished with a specific plausible route. A required mathematical obligation remains, and the prefix provides a coherent partial route plus a concrete next step toward satisfying it. Local mistakes do not automatically rule this out if a plausible repair is identifiable from the prefix. Generic exploration, restating the problem, or saying 'need to solve' is insufficient by itself.
C — stalled or contradictory without an identified repair route. The prefix is cycling, relies on unresolved contradictions, or has no specific credible remaining route. Do not use length, repeated words, or low confidence alone to assign this category.
U — uncertain. The prefix does not support a defensible distinction, including cases where required correctness/feasibility judgments exceed what can be assessed without solving the remaining problem.

For every case provide an exact contiguous prefix quote (up to 300 characters), a remaining_obligation description (for A, explain that no required obligation remains apparent), a brief reason, and confidence high/medium/low. Quote evidence from the prefix, not the question. Do not rely on any outcome or answer key. U is permitted and should be used when needed.

Output one JSON object per case to your assigned annotations.jsonl, with keys case_id,label,evidence,remaining_obligation,reason,confidence. Append each small batch promptly. Never rewrite a prior judgment after outcome access. You may fix formatting or an incorrect quote before completion. Read all 57 cases, using modest batches to manage context. Work independently. At completion write reader-attestation.json listing every file accessed, confirming no outcome/other-reader access, cases completed, and any limitations. Include that both readers are AI rather than human. Do not assign labels mechanically by keyword.
