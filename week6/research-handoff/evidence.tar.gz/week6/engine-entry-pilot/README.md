# Engine-entry attribution pilot

Two matched burst/recovery blocks retain the previous model, runtime, prompts,
sampling, answer cap, deadlines and grading. Block 0 runs arrival, entry, live.
Block 1 runs entry, live, arrival. Each block has 36 measured responses and
seven engineering probes.

The entry arm inherits the HTTP provisional budget. At first worker admission
it applies the same pressure-based 8K-to-4K reduction as live to the same
scheduler snapshot. The resulting budget is stored by request identity and
retained on subsequent worker row additions. Worker events log both budgets.

The gate checks a zero-progress reduction under waiting, two 8K requests that
remain protected when a third request queues, and a drained 8K recovery.
Gate failures stop measurement. Each completed block has its own server,
raw responses, scheduler and worker logs, executed sources and runtime manifest.
The allocation exit hook records the frozen H1 decision from available blocks.
The two 170-minute block guards leave 20 minutes inside the six-hour allocation
for readiness checks and analysis. The 20-minute gate budget is per block.

Run readiness.py for CPU tests. Run readiness.py --runtime in the pinned PACE
environment for import and version verification. The allocation script takes
the pinned Python, model, results directory and frozen source root as arguments.
