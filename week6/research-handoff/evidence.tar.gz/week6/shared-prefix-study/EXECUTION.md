# Execution specification approved November 7

User authorized preparation, engineering validation and submission in this chat. The approved scope is the shared-prefix opportunity study, with engineering gates first inside one allocation.

Hardware is one L40S 48 GB, eight CPU cores, 64 GB host RAM, six-hour maximum on ice-gpu. All measured prefixes and branches use that GPU. The six-hour test-only forecasts at preparation were November 8 at 22:24 for L40S, 22:18 for H100 and 23:44 for A100 in PACE's reported timezone. They are provisional scheduler estimates, not guaranteed starts. L40S was chosen to exercise an alternative resource at the user's request. No claim that this snapshot predicts a shorter wait. New timing data is specific to this hardware.

The original protocol's H100 duration estimate remains background. The exact sampling, 4K/8K boundaries, cue and grading are preserved. One active sequence is the isolated study design. An occupied-device or memory/backend compatibility failure stops before scientific data, preserving logs.

Implementation resolves the random comparator as 10,000 random assignments at the selected continuation count, reporting both unconditional mean correctness and the subset meeting the 85% fixed-long token ceiling. Report that subset's sample count and flag an empty subset as unsupported. No threshold search occurs on evaluation.

Two synthetic engineering cases use at most six generation calls. One holds reasoning open through the exact 4K and 8K boundaries. The corrected early-answer fixture supplies a complete controlled transcript, with one close token before 4K and an answer crossing the checkpoint. A separate unmodified sample observes natural closure. Synthetic gates establish mechanics only. CPU tests check natural closure at arbitrary positions, the legacy answer cap and request offsets. Worker initialization also checks raw softmax numerically. Source inspection verifies that the pinned sampler computes those log probabilities before sampling transforms.

The all-calls logprob collection is diagnostic overhead and is charged separately from hypothetical online policy cost. Service overhead is not claimed measured by this study. Future validation must profile an online implementation, potentially logging only the checkpoint window.

All 60 scheduled prefixes, including early closures and failed/capped cases, remain in the manifest. Eligible prefixes generate two branches from identical token IDs. Early closures share their one completed answer across both policy outcomes. There are at most 180 measured calls and 120 branch outcomes, plus six engineering calls. Calibration is generated first and sealed before evaluation.

Per-call alarms are 300 seconds, engine startup 600 seconds, engineering aggregate 1,200 seconds and measurement 16,200 seconds with 900-second reserve before another pair. An outer timeout stops generation at 340 minutes and allows 30 seconds cleanup. Slurm caps the allocation at six hours. Neither incomplete studies nor unfavorable results trigger retries or new jobs.

Actual compute accounting includes re-prefill and both suffixes. Hypothetical online branch cost counts shared prefix once. The CPU analysis saves every pair grade and extraction issue and applies the frozen opportunity/selector rules. Queue replay and follow-up serving experiments require a later review.

First-output time is saved for every engine call. It includes prefill, IPC and the first decoded token. It is a prefill-inclusive timing proxy, rather than an exact kernel prefill measurement. Actual study wall time includes all repeated prefills. Seamless continuation service time remains a later measurement requirement.


## Engineering correction approved November 8

Preserve failed job 6865548 and source lock dcb0cf48ae6e3e7395ac1807640cec1338068ad50ac13287c691fd41931460dc. Its artificial first-token close was followed by another model-generated close. The old gate correctly rejected the output, but it did not provide a controlled test of the early-answer path.

The replacement uses three boundary calls as before, then two calls for a fully controlled transcript. The transcript contains 4,090 safe synthetic tokens, one close token, a prescribed short answer and EOS. The prefix call stops at 4,096 with the answer incomplete. The standard early-answer path resumes from those exact IDs and finishes the prescribed suffix once, sharing the outcome across both policy choices. It must reproduce the full fixture byte for token and retain its global answer-cap counter. All injected tokens are marked as engineering data.

The sixth and final permitted engineering call is a normal model sample on a simple arithmetic instruction with no synthetic tokens. Its natural closure is observed separately and reported explicitly. If it has multiple closing tokens or reopens thinking after closing, the gate rejects it. If it has not closed within the 4K observation, that absence is recorded; the controlled fixture still establishes the early-answer path.

The malformed multiple-close transcript remains invalid under the original audit function. Regression tests cover the failed pattern and checkpoint-crossing early answers. Dataset, split, scientific sampling settings, 4K/8K budgets, seed schedule, cue, legacy answer allowance, grading and analysis remain byte-identical or AST-identical to the failed snapshot. One corrected allocation is authorized. No automatic further retry follows.


## Initial opening-token correction approved November 8

Preserve failed job 6867511 and its source snapshot 41a74c7e59b8a1fb95d0d64ba20716c22060bfca9b9354ddbdf82a2e78238888. All six GPU engineering calls passed. The first measured prefix then exposed an invalid assertion that a model-generated opening-think token must be absent. Its only opening token was at position zero, and the prompt ended at the assistant header.

Allow a single model-generated opening token at position zero. Keep rejection of an additional opening token and of reopening after closure. Apply the same check to prefixes and completed suffixes. Preserve every token verbatim, including the initial opener, and count it in the existing 4,096/8,192-token budgets. No stripping, re-tokenizing or budget offset adjustment.

A frozen regression fixture copies the exact failed prefix token IDs and last 256 sampled log probabilities from q19-b0, with its original token hash. CPU tests verify acceptance, unchanged hash, score computation and forced cue start at exactly 4,096. Additional tests reject reopening and duplicate openers. Scientific spec, dataset and split, seed schedule, cue, answer allowance, completion grading, selector analysis and GPU engineering recipe remain unchanged. One replacement allocation is authorized; subsequent retries require review.
