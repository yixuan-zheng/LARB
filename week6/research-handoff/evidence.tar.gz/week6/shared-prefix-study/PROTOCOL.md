# Shared-prefix reasoning opportunity study

Review draft v1, November 7, 2026. This document proposes a bounded diagnostic study. Approval of the executable implementation and resource request follows protocol review. Numeric criteria below are proposed engineering decision rules, not power calculations or formal noninferiority guarantees.

## Question and decision

At a 4,096-token reasoning prefix, can a single inexpensive confidence statistic identify where preserving an 8,192-token ceiling is valuable? How much benefit remains after measurement overhead and prediction error? First measure the allocation opportunity, then evaluate one fixed signal. A successful diagnostic earns review of concurrent serving validation.

The engine-entry H1 failed its frozen criteria. Keep that negative result closed. Earlier independently generated 4K/8K responses cannot supply paired continuation labels because their prefixes can differ.

## Cohort and split

Propose all 30 questions from MathArena/aime_2024_I and MathArena/aime_2024_II, 15 from each. Dataset identity must be checked against the local inventory before freezing. These are fresh to this project's controller development, subject to that inventory check. They may have appeared in model training. Do not claim contamination-free evaluation.

Sources are https://huggingface.co/datasets/MathArena/aime_2024_I and https://huggingface.co/datasets/MathArena/aime_2024_II. Before inference, pin repository revisions, downloaded files, license attribution, exact question text and integer answers, and normalized-text overlap checks against all earlier LARB study inputs. A duplicate or missing item blocks readiness for review rather than prompting an outcome-dependent substitution.

Rank stable IDs consisting of competition and original problem index by SHA256 of `larb-prefix-v1:<stable-id>`. Within each competition, the first five ranked questions form calibration and the other ten evaluation. Thus 10 calibration and 20 evaluation questions. Use two independent prefix seeds per question, bases 36222 and 46222, plus the stable 1–30 question index. Keep both seeds of a question together. This gives 60 planned prefix instances, 20 calibration and 40 evaluation. Answer keys are available only to grading and offline opportunity analysis. Controller features use the prefix alone. Seal the calibration policy before revealing evaluation outcomes.

This small evaluation can identify a mechanism opportunity but may be statistically inconclusive. Two seeds are repeated trajectories, not 40 independent evaluation questions. No automatic question expansion follows an inconclusive result.

## Pinned generation

Use Qwen3-4B revision `1cfa9a7208912126459214e8b04321603b3df60c`, BF16, H100 80 GB, vLLM 0.11.2, torch 2.9.0 and Transformers 4.57.6. Reuse the original prompt template with thinking enabled and integer-box suffix, temperature 0.6, top_p 0.95, top_k 20, eager execution, max_model_len 24576 and GPU memory utilization 0.8. One active request at a time isolates the diagnostic. Keep prefix caching disabled. No load/deadline claim is attached to these measurements.

Allow natural reasoning closure. If the model closes thinking before the checkpoint, complete its answer once using the legacy 2,048-token answer allowance, record it as ineligible for branching and use that same outcome under every allocation policy. Never suppress natural closure to increase eligible counts.

For a still-open prefix, stop before sampling generated token 4,097. Preserve exactly 4,096 generated token IDs, original prompt IDs, their combined hash, and sample metadata. Branch from that saved token sequence through the token-input API. Re-prefill is acceptable for this isolated diagnostic and must be measured separately. Prefix text decoding and re-tokenization are forbidden.

Short branch injects the existing exact cue at position 4,096. Long branch continues with the original sampling settings, closes naturally if it chooses, and otherwise injects the same cue at total reasoning position 8,192. The cue is `\n\nI will stop checking and give the final answer now.\n</think>\n\n`. Both branches retain the existing answer allowance, forced EOS and legacy answer-cap accounting, including cue tokens following the close token.

Use distinct deterministic continuation seeds derived from prefix seed and branch name. A shared prefix controls the pre-intervention history. It does not make stochastic suffixes identical. One suffix sample per branch estimates a paired realized contrast with substantial noise. Do not claim an individual request's expected causal effect is known. Alternate short/long execution order by ranked question index plus seed block, recording actual order.

## Engineering gates and readiness

The present runner supports token-ID inputs but produces complete responses. It needs checkpoint capture, branch-local counters and checkpoint log-probability logging. Existing saved records do not establish that this works. Implementing these is a subsequent reviewed step.

Use old development prompts only for up to six engineering generation calls, two sets of prefix, short and long. Demonstrate exact prefix identity, global counter offsets, exact cue IDs and positions, the original answer-cap boundary, natural early closure, and normal EOS. Combine deterministic CPU boundary tests with these GPU examples. The gate must inspect raw token IDs and branch-local state. No correctness-based gate.

Before submission freeze the executed sources, dataset/split, question order, seeds, branch order, signal definition, calibration grid, timeouts, source hashes and model file hashes. Verify log probabilities have the declared semantics in this pinned vLLM runtime. A mismatch stops readiness. No silent alternative signal or changed runtime.

## One proposed signal

For each of the last 256 generated reasoning tokens before 4K, record the log probability of the sampled token under the full model softmax before temperature and top-p/top-k truncation. Signal S is the arithmetic mean of those 256 log probabilities. A low S is the single predeclared indication to preserve the longer budget. This direction is a hypothesis. Do not flip it after evaluation.

Exclude forced cue tokens. Record whether the API actually provides pre-sampling probabilities by checking its code path and a tiny controlled example. This statistic is not full entropy and is not the original DeepConf top-k window statistic. It is an inexpensive candidate inspired by confidence work. Do not add repetition, answer markers or a learned feature combination to rescue a weak result.

Measure incremental observation overhead on development prompts with logging enabled and disabled, using paired orders and three repetitions per condition in CPU/instrumentation profiling where possible. GPU profiling requires an explicit later envelope if it exceeds the six-call gate. Until measured, report offline cost sensitivity using 0%, 1%, 5% and 10% added service time, not a zero-overhead claim.

## Opportunity and selector analysis

Primary analysis includes all 40 evaluation prefix instances, including early closures and capped/missing branches. Report eligible results additionally. A missing or capped branch scores incorrect. Preserve all raw text and tokens and review every extraction flag. Keep the legacy final-phase integer grading fixed. No accepting a correct intermediate reasoning answer.

For each eligible pair report short-wrong/long-correct, short-correct/long-wrong, both-correct, both-wrong, incremental reasoning and total tokens, final-answer cost, measured suffix time and replay prefill time. A long branch can be cheaper than a short branch, so use measured differences without assuming nonnegative costs.

Report an oracle accuracy–token frontier over feasible branch assignments, fixed-short, fixed-long and random allocation at matched token ceilings. Charge the shared prefix once per hypothetical online request. Charge both suffixes and repeated prefills to actual study GPU usage. These are different accounting questions.

Calibration chooses one threshold among S quantiles at 0%, 25%, 50%, 75%, 100% of eligible calibration prefixes, plus the always-short and always-long rules. Continue when S is below the threshold. Choose the most accurate rule costing at most 85% of calibration fixed-long total output tokens, then lower tokens, then the more conservative continuation rule. If no rule is feasible, declare the selector infeasible. Freeze the threshold and apply once to evaluation. Random allocation is an average over 10,000 fixed-seed assignments subject to the same token ceiling, used only as a diagnostic comparator. An equal continuation-rate random comparator is reported separately.

Bootstrap questions with both seeds grouped, 10,000 replicates and fixed seed 56222. Report 95% intervals for accuracy differences and token ratios. Keep the learned rule fixed for conditional evaluation uncertainty and explicitly state that this omits calibration-selection variance. No treating token instances as independent questions.

## Proposed decision rules

Opportunity gate on evaluation succeeds only if an oracle assignment at <=85% of fixed-long tokens can match fixed-long correctness and exceed fixed-short correctness by at least two answers out of 40. These values define a practically interesting diagnostic opportunity. If it cannot, stop this signal branch. They do not imply a significant population gain.

A selector earns concurrent-validation review only if evaluation token ratio is <=0.85, overall correct count is at least fixed-long, it recovers >=50% of the oracle's positive correctness gain over fixed-short at that ceiling, and beats the mean matched-budget random correctness. Additionally its positive advantage over fixed-short must have a question-bootstrap 95% lower bound above zero. If point criteria pass but the interval includes zero, classify inconclusive and review. If either seed block loses more than one correct answer relative to fixed-long, classify unstable and inconclusive even if pooled requirements pass. Report all block results.

If <=10 evaluation pairs reach 4K or fewer than four evaluation pairs have discordant correctness, classify low-information/inconclusive. A failed mechanics gate, missing provenance, or missing branch is a protocol failure. Preserve it and stop for review. Do not retry unfavorable outcomes, alter the signal, or replace questions.

A selector success remains conditional on unmeasured deployment overhead. For each overhead scenario report how much incremental useful compute the estimated savings can cover. Concurrent validation must measure real log-probability extraction, CPU/GPU synchronization, batching effects and deadlines, then predeclare an application-justified correctness margin. This diagnostic cannot establish goodput.

## Queue connection and limits

Use old queue traces only for exploratory sensitivity after the paired study. Their question identities and service costs differ from the proposed new cohort. Directly substituting new outcomes into those traces is not a validated counterfactual replay. Report an optimistic bound and uncertainty rather than a goodput prediction. Re-prefill suffix timings likewise do not equal seamless in-engine continuation timings.

The subsequent review should decide whether to validate one selective policy against pressure-only at matched intervention cost and frozen-budget baselines. Both correctness and completion deadlines must be measured on the same outputs. The frozen-budget scheduling backup can be assessed with CPU trace replay independently if this study finds little opportunity.

## Count, duration and failure envelope

60 prefix calls and up to 120 suffix calls, with early closures reducing suffix count, produce up to 120 measured branch outcomes. The maximum engineering gate adds six calls. At full caps the measurement entails 245,760 shared prefix reasoning tokens, up to 245,760 continuation reasoning tokens and roughly 245,760 answer tokens, about 0.74 million generated tokens plus cues/EOS. Re-prefill processes up to 491,520 repeated prefix tokens plus question prompts. Those prefills are study overhead.

Previous isolated H100 8K measurements were approximately 100 seconds per response. Scaling by decode volume suggests roughly 2–3 hours, while branch prefills, logging and startup suggest a planning range of 3–5 hours. This is an engineering estimate rather than a throughput measurement of the new path. Propose one six-hour H100 allocation, both seed blocks sequentially. Prefix timeout 300 s, suffix timeout 300 s, startup 600 s, aggregate engineering timeout 1,200 s and measured-study timeout 16,200 s. The outer Slurm cap is six hours. A timed-out call is saved as failed and its pair is retained. Stop on repeated engine/infrastructure failure. Never automatically rerun.

The time envelope can produce an incomplete study under unexpectedly slow execution. Preserve incomplete coverage and classify inconclusive instead of increasing the cap or resubmitting automatically. Readiness requires reviewing these estimates after a mechanics implementation exists.

## Deliverables and review boundary

Deliver immutable raw prefixes, branch tokens/text, signal logs, per-call timings, manifest and failures, plus independent CPU grading, grouped uncertainty, frontier and one sealed selector decision. First review this draft's dataset, resource envelope and proposed numeric thresholds. Then implement and CPU-test the runner and prepare the exact source/data lock. GPU submission requires a separate instruction. No additional experiment follows automatically.
