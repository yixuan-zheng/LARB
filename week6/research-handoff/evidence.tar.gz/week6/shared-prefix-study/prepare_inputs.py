"""Normalize immutable parquet files and pin the prospective split."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]


def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def normalize(text):
    return re.sub(r'\s+', '', text).casefold()


if __name__ == '__main__':
    import pyarrow.parquet as parquet
    questions = []
    sources = []
    for competition in ['I', 'II']:
        meta = json.loads(Path(f'/private/tmp/aime24-{competition}-meta.json').read_text())
        path = HERE / 'inputs' / f'aime-{competition}.parquet'
        rows = parquet.read_table(path).to_pylist()
        assert len(rows) == 15
        ranked = sorted(rows, key=lambda r: hashlib.sha256(
            f"larb-prefix-v1:aime2024{competition}:{r['problem_idx']}".encode()).hexdigest())
        calibration = {r['problem_idx'] for r in ranked[:5]}
        for row in sorted(rows, key=lambda r: r['problem_idx']):
            assert type(row['answer']) is int and 0 <= row['answer'] <= 999
            questions.append(dict(id=len(questions)+1,
                stable_id=f"aime2024{competition}:{row['problem_idx']}",
                competition=competition, problem=row['problem'], answer=row['answer'],
                split='calibration' if row['problem_idx'] in calibration else 'evaluation'))
        sources.append(dict(repository=meta['id'], revision=meta['sha'],
            file=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    assert len({normalize(q['problem']) for q in questions}) == 30
    # Canonical inputs are sufficient to cover copied collection sources as well.
    prior = {}
    for path in REPO.glob('week6/**/inputs/problems.json'):
        if 'sources' in path.parts or path.parent == HERE / 'inputs':
            continue
        data = json.loads(path.read_text())
        if isinstance(data, list):
            for row in data:
                if isinstance(row, dict) and isinstance(row.get('problem'), str):
                    prior[normalize(row['problem'])] = str(path.relative_to(REPO))
    overlaps = [q['stable_id'] for q in questions if normalize(q['problem']) in prior]
    assert not overlaps, overlaps
    write(HERE / 'inputs' / 'questions.json', questions)
    write(HERE / 'inputs' / 'manifest.json', dict(sources=sources,
        unique_prior_prompts_checked=len(prior), overlaps=overlaps,
        questions=30, calibration_questions=10, evaluation_questions=20))
